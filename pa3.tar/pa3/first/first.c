#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

unsigned long int counter = 0, write = 0, hit = 0, miss = 0, read = 0, count = 0;

struct cacheBlocks { // what each cache should have in their block
	int valid;
	size_t tag;
	unsigned long int time;
	unsigned long int lru;
}; 
struct cacheBlocks **cache;

void setZeroBits(struct cacheBlocks **cache1, int setSize, int blocks)
{
	int i,j;
	for( i = 0; i < setSize; i++)
	{
		for( j = 0; j < blocks; j++)
		{
			cache1[i][j].valid = 0;
			cache1[i][j].time = 0;
			cache1[i][j].lru = 0;
		}
	}
}

void doLRU(struct cacheBlocks **cache1, size_t addTag, int blocks, int setIndex)
{
	int i;
	unsigned long int minTime = cache1[setIndex][0].lru;
	int minTimePos = 0;

	for ( i = 0; i < blocks; i++)
	{
		if (minTime > cache1[setIndex][i].lru)
		{
			minTime = cache1[setIndex][i].lru;
			minTimePos = i;	
		}
	}

	cache1[setIndex][minTimePos].tag = addTag;
	cache1[setIndex][minTimePos].valid = 1;
	cache1[setIndex][minTimePos].lru = counter;
}

void doFIFO(struct cacheBlocks **cache1, size_t addTag, int blocks, int setIndex)
{
	int i;
	for ( i = 0; i < blocks - 1; i++)
	{
		cache1[setIndex][i].tag = cache1[setIndex][i + 1].tag;
		cache1[setIndex][i].time = cache1[setIndex][i + 1].time;
		cache1[setIndex][i].lru = cache1[setIndex][i + 1].lru;
		cache1[setIndex][i].valid = cache1[setIndex][i + 1].valid;
	}
	cache1[setIndex][blocks - 1].tag = addTag;
	cache1[setIndex][blocks - 1].valid = 1;
	cache1[setIndex][blocks - 1].time = 1;
	cache1[setIndex][blocks - 1].lru = counter;
}

int hitChecking(struct cacheBlocks **cache1, size_t addTag, int setIndex, int blocks)
{
	int i;
	int result = 0; 
	for ( i = 0; i < blocks; i++)
	{
		if (cache1[setIndex][i].tag == addTag)
		{
			result = 1;
			cache1[setIndex][i].time++;
			cache1[setIndex][i].lru = counter;
			break;
		}
	}
	return result;
}

int fullBlock(struct cacheBlocks **cache1, int blocks, int setIndex)
{
	int i;
	int result = -1;
	for( i = 0; i < blocks; i++)
	{
		if(cache1[setIndex][i].valid == 0)
		{
			result = i;
			break;
		}
	}
	return result;
}

void writeCache(struct cacheBlocks **cache1, size_t addTag, char check, int blocks, int setIndex)
{
	int freeSpace = fullBlock(cache1, blocks, setIndex);
	if (freeSpace != -1)
	{
		cache1[setIndex][freeSpace].tag = addTag;
		cache1[setIndex][freeSpace].valid = 1;
		cache1[setIndex][freeSpace].lru = counter;
		cache1[setIndex][freeSpace].time++;
	}
	else if (freeSpace == -1)
	{
		if (check == 'f')
			doFIFO(cache1, addTag, blocks, setIndex);
		else if(check == 'i')
			doLRU(cache1, addTag, blocks, setIndex);
	}
}

int find_setIndex(size_t address, int blocksBit, int setBits)
{
	int mask = (1 << setBits) - 1;
	int setIndex = (address >> blocksBit) & mask;

	return setIndex;
}

size_t findTag(size_t address, int blocksBit, int setBits)
{
	size_t tagAddy = address >> (blocksBit + setBits);
	return tagAddy;
}

void matrixAllocation(int rows, int cols)
{
	int i;
	cache = malloc(rows * sizeof(struct cacheBlock*));
	for ( i = 0; i < rows; i++)
		cache[i] = malloc(cols * sizeof(struct cacheBlocks));	
}

void clearMatrix(struct cacheBlocks **cache1, int row)
{
	int i;
	for ( i = 0; i < row; i++)
	{
		free(cache1[i]);
		cache1[i] = NULL;
	}
	free(cache1);
	cache1 = NULL;
}

int powerofTwo(int x)
{
	if (x == 0)
		return 0;

	if (ceil(log2(x)) == floor(log2(x)))
		return 1;
	else
		return 0;
}

int main(int argc, char** argv)
{
	if (argc != 6)
	{
		printf("Error: insufficient amount of arguments");
		return 0;
	}

	int sizeofCache = atoi(argv[1]);
	if( powerofTwo(sizeofCache) == 0)
	{
		printf("Error: Cache size is not a power of 2");
		return 0;
	}

	int sizeofBlock = atoi(argv[2]);
	if (powerofTwo(sizeofBlock) == 0)
	{
		printf("Error: Size of block is not a power of 2");
		return 0;
	}


	char policy; // FIFO or LRU 
	int assoc; // direct. n, or assoc
	int putSize;
	char *traceFile = argv[5];
		
	if(argv[3][0] == 'f')
		policy = 'f';
	else if(argv[2][0]== 'l')
		policy = 'l';

	FILE* inFile;
	inFile = fopen(traceFile, "r");
	if (inFile == NULL)
	{
		printf("error");
		return 0;
	}

	if(argv[4][0] == 'd')
	{
		assoc = 1;
		putSize = sizeofCache / sizeofBlock; //direct mapping
	}
	else if(argv[4][5] != ':')
	{
		putSize = 1;
		assoc = sizeofCache / sizeofBlock;
	}
	else
	{
		sscanf(argv[4], "assoc:%d", &assoc);
		if (powerofTwo(assoc) == 0)
		{
			printf("error");
			return 0;
		}
		putSize = sizeofCache / sizeofBlock / assoc;
	}

	

	int sb = log2(putSize);
	int bob = log2(sizeofBlock);
	
	matrixAllocation(putSize, assoc);
	setZeroBits(cache, putSize, assoc);
	size_t add;
	char read_write;

	while (!feof(inFile))
	{
		fscanf(inFile, "%c %zx\n", &read_write, &add); // there was a comma between %c and %z
		if (read_write == '#')
			break;

		counter++;

		int indexSet = find_setIndex(add, bob, sb);
		size_t theTag = findTag(add, bob, sb);

		int miss_hit = hitChecking(cache, theTag, indexSet, assoc);
		if (read_write == 'W')
			write++;

		if (miss_hit == 1) // hit
			hit++;
		else // miss
		{
			miss++;
			read++;
			writeCache(cache, theTag, policy, assoc, indexSet);	
		}
	}

	printf("Memory reads: %lu\n", read);
	printf("Memory writes: %lu\n", write);
	printf("Cache hits: %lu\n", hit);
	printf("Cache misses: %lu", miss);

	clearMatrix(cache, putSize);
	fclose(inFile);
	return 0;
}

/*
173
334
827
173
*/
